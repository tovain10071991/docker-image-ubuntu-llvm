#import <Cocoa/Cocoa.h>

int main()
{
	id foo = @{@1 : @2, @2 : @3};
	int x = 34;
	return 0; // Stop here
}
